# MarbleCut — como rodar no seu servidor

## Antes de tudo: o que hospedar aqui muda (e o que não muda)

Este editor processa vídeo **no navegador de quem acessa**, usando a CPU e a GPU
daquele aparelho. Hospedar a página no seu servidor **não move o processamento
para o servidor** — ele continua acontecendo na máquina do visitante. O que o seu
servidor faz é entregar um arquivo HTML de 800 KB.

Isso é bom para privacidade e custo (o servidor nunca vê o vídeo, e a banda é
quase zero), mas se o seu objetivo é *o servidor* converter arquivos grandes,
essa arquitetura não faz isso — seria outro programa, com ffmpeg no servidor,
fila de processamento e armazenamento.

## Opção 1 — arquivo único (mais simples)

`marblecut-standalone.html` é o editor inteiro num arquivo só, sem dependência
externa. Joga onde quiser:

```bash
# nginx / apache: só copiar
cp marblecut-standalone.html /var/www/html/index.html
```

```bash
# ou servir na hora, para testar
python3 -m http.server 8080   # abre http://localhost:8080
```

Funciona até abrindo direto do disco, sem servidor nenhum (`file://`).

**Exigência importante:** navegadores só liberam a câmera de codificação
(WebCodecs) em **HTTPS** ou em `localhost`. Num servidor com HTTP puro o editor
não vai codificar. Use um certificado — Let's Encrypt resolve de graça.

## Opção 2 — projeto completo (para modificar)

```bash
cd marblecut
npm install
npm run dev                # desenvolvimento, http://localhost:3000
npm run build && npm start # produção
npm run build:standalone   # regera o arquivo único
```

Requer Node 20 ou superior.

## Sobre arquivos grandes

**Entrada:** o vídeo de origem **não** é carregado inteiro na memória. O
navegador lê pedaços sob demanda direto do disco, então abrir um arquivo de
vários GB não estoura a RAM.

**Saída:** aqui está o limite real. O arquivo exportado é montado inteiro na
memória antes de virar download. Na prática:

| Exportação | Situação |
| --- | --- |
| até ~500 MB | tranquilo, inclusive em celular |
| 1–2 GB | funciona em desktop com RAM sobrando |
| acima disso | tende a estourar a aba |

Para o caso de criativo vertical (9:16, teto de 500 MB) isso nunca é problema —
um vídeo de 1 minuto a 6 Mbps dá cerca de 45 MB.

Se precisar exportar arquivos realmente grandes, o caminho é trocar o destino da
codificação (`BufferTarget`) por gravação direta em disco via File System Access
API, em `src/lib/export.ts`. Aí o limite passa a ser o espaço livre, não a RAM.

## Navegadores

Precisa de WebCodecs: Chrome, Edge e Opera atualizados, ou Safari 17+. O Firefox
ainda não expõe `VideoEncoder` — o editor avisa em vez de quebrar no meio.

Para envio de criativo, prefira **Chrome ou Edge**: MP4 nessas plataformas
significa H.264, e navegadores sem codec proprietário geram MP4 com VP9/AV1, que
pode ser recusado. O editor detecta e avisa antes de exportar.
